
For pixel snapping props to the grid when placing them, first download the awesome pixel art shader by talecrafter at this address:

https://gist.github.com/talecrafter/81e2f3bb7fb4b4fc367e7b851772b646#file-sprites-pixelart-shader

and import it in the project.
Create a new material, drag the shader at the bottom of the inspector field of the material.
Under the Pixels Per Unit section in the material, type 48

Now you can assign the material to the prefabs, and apply it, and BAM! your props are perfectly snapping to the grid!

