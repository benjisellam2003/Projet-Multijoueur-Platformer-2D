﻿using UnityEngine;

public class Die : StateMachineBehaviour
{
    override public void OnStateExit(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        //Destroy(animator.gameObject);
    }
}
