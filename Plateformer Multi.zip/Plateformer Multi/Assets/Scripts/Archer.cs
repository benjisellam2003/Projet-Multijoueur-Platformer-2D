﻿using UnityEngine;

namespace Assets.Scenes
{
    class Archer : Character
    {
        //Object _arrow = Resources.Load("Resources/Prefabs/Arrow");

        //public Object Arrow { get => _arrow; set => _arrow = value; }

        public Archer() : base(KeyCode.LeftArrow, KeyCode.RightArrow, KeyCode.UpArrow, KeyCode.RightShift, KeyCode.RightControl, 12, 25, "Archer", "ArcherHpGauge")
        {
        }

        //public override void Attack()
        //{

        //}
    }
}