﻿using System.Collections.Generic;
using Assets.Scenes;
using UnityEngine;

public class Controlls : MonoBehaviour
{
    Knight knight;
    Archer archer;

    LayerMask groundLayer;
    LayerMask playerLayer;

    Dictionary<string, int> damages = new Dictionary<string, int>();

    void Start()
    {
        const string knightName = "Knight";
        const string archerName = "Archer";

        groundLayer = LayerMask.GetMask("Ground");
        playerLayer = LayerMask.GetMask("Player");

        if (GameObject.Find(knightName) != null)
        {
            knight = new Knight();
        }
        if (GameObject.Find(archerName) != null)
        {
            archer = new Archer();
        }

        damages.Add("Spikes", 27);
    }

    void Update()
    {
        if (knight != null)
        {
            knight.KeyPressed();
        }
        if (archer != null)
        {
            archer.KeyPressed();
        }
    }

    void FixedUpdate()
    {
        knight.AnimatorTree.SetBool("IsGrounded", knight.CharacterObject.GetComponent<Rigidbody2D>().IsTouchingLayers(groundLayer) || knight.CharacterObject.GetComponent<Rigidbody2D>().IsTouchingLayers(playerLayer));
        archer.AnimatorTree.SetBool("IsGrounded", archer.CharacterObject.GetComponent<Rigidbody2D>().IsTouchingLayers(groundLayer) || archer.CharacterObject.GetComponent<Rigidbody2D>().IsTouchingLayers(playerLayer));

        List<Collider2D> contacts = new List<Collider2D>();

        knight.CharacterObject.GetComponent<Collider2D>().GetContacts(contacts);

        foreach (Collider2D contact in contacts)
        {
            if (damages.ContainsKey(contact.gameObject.tag))
            {
                knight.Hit(damages[contact.gameObject.tag]);
            }
        }
        
        archer.CharacterObject.GetComponent<Collider2D>().GetContacts(contacts);

        foreach (Collider2D contact in contacts)
        {
            if (damages.ContainsKey(contact.gameObject.tag))
            {
                archer.Hit(damages[contact.gameObject.tag]);
            }
        }
    }
}