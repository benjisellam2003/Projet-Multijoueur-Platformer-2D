﻿using System.Collections.Generic;
using Assets.Scenes;
using UnityEngine;

public class Controlls : MonoBehaviour
{
    Knight knight;
    Archer archer;

    LayerMask groundLayer;
    LayerMask playerLayer;
    LayerMask enemyLayer;

    Dictionary<string, int> damages = new Dictionary<string, int>();

    void Start()
    {
        const string knightName = "Knight";
        const string archerName = "Archer";

        groundLayer = LayerMask.GetMask("Ground");
        playerLayer = LayerMask.GetMask("Player");

        if (GameObject.Find(knightName) != null)
        {
            knight = new Knight();
        }
        if (GameObject.Find(archerName) != null)
        {
            archer = new Archer();
        }

        damages.Add("Spikes", 1);
    }

    void Update()
    {
        if (knight != null)
        {
            knight.KeyPressed();
        }
        if (archer != null)
        {
            archer.KeyPressed();
        }
    }

    void FixedUpdate()
    {
        knight.AnimatorTree.SetBool("IsGrounded", knight.CharacterObject.GetComponent<Rigidbody2D>().IsTouchingLayers(groundLayer) || knight.CharacterObject.GetComponent<Rigidbody2D>().IsTouchingLayers(playerLayer));
        archer.AnimatorTree.SetBool("IsGrounded", archer.CharacterObject.GetComponent<Rigidbody2D>().IsTouchingLayers(groundLayer) || archer.CharacterObject.GetComponent<Rigidbody2D>().IsTouchingLayers(playerLayer));        

        if (knight.CharacterObject.GetComponent<Rigidbody2D>().IsTouchingLayers(enemyLayer) && !knight.AnimatorTree.GetBool("IsInvincible"))
        {
            Collider2D[] collisions = { };

            knight.CharacterObject.GetComponent<Rigidbody2D>().GetContacts(collisions);

            foreach (Collider2D collision in collisions)
            {
                if (damages.ContainsKey(collision.gameObject.tag))
                {
                    knight.Hit(damages[collision.gameObject.tag]);
                }
            }
        }
    }
}