﻿using Assets.Scenes;
using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    Knight knight;
    Archer archer;

    void Start()
    {
        const string knightName = "Knight";
        const string archerName = "Archer";

        if (GameObject.Find(knightName) != null)
        {
            knight = new Knight();
        }
        if (GameObject.Find(archerName) != null)
        {
            archer = new Archer();
        }
    }

    void Update()
    {
        const float MULTIPLIER = 1.25f;
        const int MIN = 4;
        const int MAX = 6;
        const int posZ = 10;

        Vector2 knightPos = knight.CharacterObject.transform.position;
        Vector2 archerPos = archer.CharacterObject.transform.position;

        float distance = Vector2.Distance(knightPos, archerPos);

        Vector2 center = knightPos + (archerPos - knightPos) / 2;

        gameObject.transform.position = center;

        gameObject.transform.position -= new Vector3(0, 0, posZ);

        if (distance / MULTIPLIER <= MIN)
        {
            gameObject.GetComponent<Camera>().orthographicSize = MIN;
        }
        else if (distance / MULTIPLIER >= MAX)
        {
            gameObject.GetComponent<Camera>().orthographicSize = MAX;
        }
        else
        {
            gameObject.GetComponent<Camera>().orthographicSize = distance / MULTIPLIER;
        }
    }
}